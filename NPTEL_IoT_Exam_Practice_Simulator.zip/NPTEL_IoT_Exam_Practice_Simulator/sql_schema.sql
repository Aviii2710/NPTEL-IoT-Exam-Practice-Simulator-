create table if not exists public.iot_attempts (
  id bigint generated always as identity primary key,
  student_name text not null check (char_length(student_name) between 1 and 80),
  paper_no smallint not null check (paper_no between 1 and 4),
  score smallint not null check (score between 0 and 50),
  attempt_no integer not null check (attempt_no >= 1),
  submitted_at timestamptz not null default now()
);
create index if not exists iot_attempts_submitted_at_idx on public.iot_attempts (submitted_at desc);
create index if not exists iot_attempts_name_paper_idx on public.iot_attempts (student_name, paper_no, attempt_no desc);
alter table public.iot_attempts enable row level security;
-- Do not create public read/write policies. Only server API using the service-role key accesses this table.
