# NPTEL IoT Exam Practice Simulator

A free practice-only web app scaffold branded for Aviraj Landage.

## Important question-bank limitation
The earlier draft available in the conversation contained general topic-based questions and did **not** verify them as official NPTEL assignments/PYQs. Your requirement is that all 200 questions must come only from official course assignments/PYQs, with no repeats across the four papers. For that reason, this package does **not** invent or silently label questions as official. `data/questions.json` is intentionally empty until the official assignment/PYQ sources are provided.

Each paper must contain exactly 50 records. Required fields:
- `id`: unique ID across all four papers
- `source`: exact assignment/PYQ name, week, or exam/year
- `question`: question text
- `options`: exactly four options
- `answer`: zero-based index of correct option (0–3)
- optional `explanation`

## Included
- Responsive violet/orange/black/white student UI
- Four paper cards and 50-question paper validation
- Server-side scoring and attempt logging
- Protected admin sign-in and attempts dashboard
- Supabase table schema with row-level security enabled
- Vercel serverless API layout

## Deploy free (Vercel + Supabase)
1. Create a Supabase project and run `sql_schema.sql` in its SQL Editor.
2. Create a private GitHub repository and upload these files. Do not upload a real `.env` file or publish secrets.
3. Import the repository into Vercel (Hobby plan is free for personal/non-commercial use; check current limits/terms).
4. In Vercel Project Settings → Environment Variables, add values from `.env.example`, replacing `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` with the values from Supabase Project Settings → API. Keep the service-role key secret.
5. Deploy and open the generated Vercel URL.
6. Add only verified questions to `data/questions.json`, ensure every paper has 50 unique questions and IDs are unique across papers, then redeploy.

## Admin access
- Username: `aviii_admin`
- Password: the generated value in `.env.example` in this package. Set it as `ADMIN_PASSWORD` in Vercel environment variables. You should change it to a new strong secret before sharing the public site.

## Privacy note
Student names are self-entered and are not verified identities. The admin dashboard shows submitted attempts. Do not collect sensitive personal information. This starter intentionally does not expose results based solely on entering a student's name, because that would let someone impersonate another student. A secure personal-results feature needs a private student token or similar.

## API routes
- `GET /api/questions?paper=1`
- `POST /api/submit`
- `POST /api/admin/login`
- `GET /api/admin/attempts` (admin session required)
- `POST /api/admin/logout`

## Limitations to finish before public launch
- Insert 200 verified official assignment/PYQ questions into the bank.
- Test the deployment and admin session settings.
- If desired, implement student-specific private result retrieval using random access tokens rather than typed names.
